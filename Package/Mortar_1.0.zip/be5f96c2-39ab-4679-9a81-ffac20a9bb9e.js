﻿angular.module("umbraco").controller("Our.Umbraco.PropertyEditors.Mortar.mortarEditor", [
    '$scope',
    '$rootScope',
    'editorState',
    'umbPropEditorHelper',
    function($scope, $rootScope, editorState, umbPropEditorHelper) {

        //TODO: Do stuff...

    }
]);